package com.nikpet.blemeter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT_PERMS = 100;
    private static final int REQ_ENABLE_BT = 101;
    private static final int REQ_SAVE_CSV = 102;

    private static final UUID OWON_SERVICE = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb");
    private static final UUID OWON_CONTROL = UUID.fromString("0000fff3-0000-1000-8000-00805f9b34fb");
    private static final UUID OWON_NOTIFY  = UUID.fromString("0000fff4-0000-1000-8000-00805f9b34fb");

    private static final UUID FLUKE_SERVICE = UUID.fromString("6f289001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID FLUKE_MEAS    = UUID.fromString("6f289002-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID CCCD          = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private enum Kind { FLUKE, OWON }

    private final Handler main = new Handler(Looper.getMainLooper());
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private boolean scanning = false;
    private Kind scanKind;
    private final Map<String,BluetoothDevice> scanDevices = new LinkedHashMap<>();

    private MeterConnection fluke;
    private MeterConnection owon;

    private TextView flukeValue, flukeUnit, flukeMode, flukeStatus, flukeRssi, flukeLink, flukePackets;
    private TextView owonValue, owonUnit, owonMode, owonStatus, owonRssi, owonLink, owonPackets;
    private Button flukeConnect, flukeDisconnect, owonConnect, owonDisconnect, owonHold;
    private Button logButton, saveButton, screenButton;
    private TextView eventLog;

    private boolean logging = false;
    private boolean keepScreen = false;
    private final List<String[]> csvRows = new ArrayList<>();
    private final SimpleDateFormat stamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager bm = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm == null ? null : bm.getAdapter();

        fluke = new MeterConnection(Kind.FLUKE);
        owon = new MeterConnection(Kind.OWON);

        buildUi();
        requestBluetoothPermissionsIfNeeded();

        main.postDelayed(linkTicker, 500);
        main.postDelayed(rssiTicker, 1800);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopScan();
        fluke.close();
        owon.close();
        main.removeCallbacksAndMessages(null);
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private GradientDrawable bg(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp((int)radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return v;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setBackground(bg(Color.rgb(38,49,59), 10, Color.rgb(70,83,97)));
        b.setPadding(dp(10),dp(8),dp(10),dp(8));
        return b;
    }

    private void buildUi() {
        final int BG = Color.rgb(16,19,23);
        final int PANEL = Color.rgb(24,29,35);
        final int PANEL2 = Color.rgb(32,38,46);
        final int TEXT = Color.rgb(238,242,246);
        final int MUTED = Color.rgb(154,167,181);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(24));
        scroll.addView(root, new ScrollView.LayoutParams(-1,-2));

        TextView title = tv("BLE Meter", 24, TEXT, true);
        root.addView(title);
        TextView sub = tv("Native Android • FLUKE 289 + OWON CMS061/CMS101", 12, MUTED, false);
        root.addView(sub);
        addSpace(root, 12);

        // Fluke card
        LinearLayout fc = card(root, PANEL);
        LinearLayout fh = header(fc, PANEL2);
        fh.addView(tv("FLUKE 289",18,TEXT,true), weight());
        flukeStatus = tv("НЕ Е СВЪРЗАН",11,Color.rgb(255,113,105),true);
        fh.addView(flukeStatus);
        LinearLayout fv = horizontal(fc);
        flukeValue = tv("--",46,TEXT,true); flukeValue.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        flukeUnit = tv("",22,Color.rgb(213,221,231),false);
        fv.addView(flukeValue); addSpaceH(fv, 8); fv.addView(flukeUnit);
        flukeMode = tv("NO DATA",14,MUTED,true); fc.addView(flukeMode);
        flukeRssi = tv("RSSI  — dBm",13,TEXT,true); fc.addView(flukeRssi);
        flukeLink = tv("LINK  NO DATA",13,Color.rgb(255,113,105),true); fc.addView(flukeLink);
        flukePackets = tv("Packets: 0",12,MUTED,false); fc.addView(flukePackets);
        LinearLayout fbtns = horizontal(fc);
        flukeConnect=btn("Свържи FLUKE"); flukeDisconnect=btn("Разкачи");
        fbtns.addView(flukeConnect, weight()); addSpaceH(fbtns,8); fbtns.addView(flukeDisconnect, weight());
        flukeDisconnect.setEnabled(false);

        addSpace(root, 12);

        // Owon card
        LinearLayout oc = card(root, PANEL);
        LinearLayout oh = header(oc, PANEL2);
        oh.addView(tv("OWON CMS061",18,TEXT,true), weight());
        owonStatus = tv("НЕ Е СВЪРЗАН",11,Color.rgb(255,113,105),true);
        oh.addView(owonStatus);
        LinearLayout ov = horizontal(oc);
        owonValue = tv("--",46,TEXT,true); owonValue.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        owonUnit = tv("",22,Color.rgb(213,221,231),false);
        ov.addView(owonValue); addSpaceH(ov,8); ov.addView(owonUnit);
        owonMode = tv("NO DATA",14,MUTED,true); oc.addView(owonMode);
        owonRssi = tv("RSSI  — dBm",13,TEXT,true); oc.addView(owonRssi);
        owonLink = tv("LINK  NO DATA",13,Color.rgb(255,113,105),true); oc.addView(owonLink);
        owonPackets = tv("Packets: 0",12,MUTED,false); oc.addView(owonPackets);
        LinearLayout obtns1 = horizontal(oc);
        owonConnect=btn("Свържи OWON"); owonDisconnect=btn("Разкачи");
        obtns1.addView(owonConnect,weight()); addSpaceH(obtns1,8); obtns1.addView(owonDisconnect,weight());
        owonDisconnect.setEnabled(false);
        LinearLayout obtns2 = horizontal(oc);
        owonHold=btn("HOLD toggle"); owonHold.setEnabled(false);
        obtns2.addView(owonHold, weight());

        addSpace(root, 12);

        // Tools
        LinearLayout tools = card(root, PANEL);
        LinearLayout t1 = horizontal(tools);
        logButton=btn("Старт CSV лог"); saveButton=btn("Запази CSV");
        t1.addView(logButton,weight()); addSpaceH(t1,8); t1.addView(saveButton,weight());
        saveButton.setEnabled(false);
        LinearLayout t2 = horizontal(tools);
        screenButton=btn("Дръж екрана включен");
        t2.addView(screenButton,weight());

        addSpace(root, 12);
        eventLog = tv("",11,Color.rgb(199,208,218),false);
        eventLog.setTypeface(Typeface.MONOSPACE);
        eventLog.setPadding(dp(10),dp(10),dp(10),dp(10));
        eventLog.setBackground(bg(Color.rgb(11,14,17), 10, Color.rgb(49,58,69)));
        root.addView(eventLog, new LinearLayout.LayoutParams(-1, dp(180)));

        flukeConnect.setOnClickListener(v -> scanFor(Kind.FLUKE));
        flukeDisconnect.setOnClickListener(v -> fluke.close());
        owonConnect.setOnClickListener(v -> scanFor(Kind.OWON));
        owonDisconnect.setOnClickListener(v -> owon.close());
        owonHold.setOnClickListener(v -> owon.sendHold());
        logButton.setOnClickListener(v -> toggleLogging());
        saveButton.setOnClickListener(v -> saveCsv());
        screenButton.setOnClickListener(v -> toggleKeepScreen());

        setContentView(scroll);
    }

    private LinearLayout card(LinearLayout parent, int color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14),dp(14),dp(14),dp(14));
        c.setBackground(bg(color, 14, Color.rgb(49,58,69)));
        parent.addView(c, new LinearLayout.LayoutParams(-1,-2));
        return c;
    }

    private LinearLayout header(LinearLayout parent, int color) {
        LinearLayout h = horizontal(parent);
        h.setPadding(dp(2),dp(2),dp(2),dp(8));
        return h;
    }

    private LinearLayout horizontal(LinearLayout parent) {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.topMargin = dp(8);
        parent.addView(h,p);
        return h;
    }

    private LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0,-2,1f); }
    private void addSpace(LinearLayout l,int dpv){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(dpv))); }
    private void addSpaceH(LinearLayout l,int dpv){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(dp(dpv),1)); }

    private void requestBluetoothPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            List<String> req = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                req.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                req.add(Manifest.permission.BLUETOOTH_CONNECT);
            if (!req.isEmpty()) requestPermissions(req.toArray(new String[0]), REQ_BT_PERMS);
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT_PERMS);
        }
    }

    private boolean bluetoothPermitted() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void scanFor(Kind kind) {
        if (!bluetoothPermitted()) {
            requestBluetoothPermissionsIfNeeded();
            toast("Разреши Bluetooth/Nearby devices и опитай пак.");
            return;
        }
        if (adapter == null) { toast("Телефонът няма Bluetooth."); return; }
        if (!adapter.isEnabled()) {
            try { startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT); }
            catch (Exception e) { toast("Включи Bluetooth."); }
            return;
        }
        stopScan();
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { toast("BLE scanner unavailable."); return; }

        scanKind = kind;
        scanDevices.clear();
        scanning = true;
        log("Scanning for " + kind + "...");

        try { scanner.startScan(scanCallback); }
        catch (SecurityException e) { toast("Bluetooth permission denied."); return; }

        main.postDelayed(() -> {
            if (scanning) {
                stopScan();
                showScanResults(kind);
            }
        }, 6000);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String name = null;
            try { name = d.getName(); } catch (SecurityException ignored) {}
            if (name == null && result.getScanRecord()!=null) name=result.getScanRecord().getDeviceName();
            boolean match = matches(scanKind, name, result);
            if (!match) return;
            scanDevices.put(d.getAddress(), d);
            if (scanDevices.size()==1) runOnUiThread(() -> log("Found: " + safeName(d)));
        }
    };

    private boolean matches(Kind kind, String name, ScanResult r) {
        String n = name == null ? "" : name.toLowerCase(Locale.US);
        if (kind == Kind.FLUKE) {
            if (n.contains("fluke289")) return true;
            return advertises(r, FLUKE_SERVICE);
        } else {
            if (n.contains("bdm") || n.contains("owon") || n.contains("cms") || n.contains("clamp")) return true;
            return advertises(r, OWON_SERVICE);
        }
    }

    private boolean advertises(ScanResult r, UUID service) {
        if (r.getScanRecord()==null || r.getScanRecord().getServiceUuids()==null) return false;
        for (ParcelUuid p : r.getScanRecord().getServiceUuids()) if (service.equals(p.getUuid())) return true;
        return false;
    }

    private void stopScan() {
        if (!scanning || scanner==null) { scanning=false; return; }
        try { scanner.stopScan(scanCallback); } catch (SecurityException ignored) {}
        scanning=false;
    }

    private void showScanResults(Kind kind) {
        if (scanDevices.isEmpty()) { toast(kind + " не е намерен."); return; }
        List<BluetoothDevice> list = new ArrayList<>(scanDevices.values());
        String[] names = new String[list.size()];
        for (int i=0;i<list.size();i++) names[i]=safeName(list.get(i)) + "\n" + list.get(i).getAddress();

        new AlertDialog.Builder(this)
                .setTitle("Избери " + kind)
                .setItems(names, (d,w) -> {
                    BluetoothDevice dev=list.get(w);
                    if (kind==Kind.FLUKE) fluke.connect(dev); else owon.connect(dev);
                })
                .setNegativeButton("Отказ",null)
                .show();
    }

    private String safeName(BluetoothDevice d) {
        try {
            String n=d.getName();
            return n==null || n.isEmpty() ? "BLE device" : n;
        } catch (SecurityException e) { return "BLE device"; }
    }

    private final class MeterConnection {
        final Kind kind;
        BluetoothGatt gatt;
        BluetoothDevice device;
        BluetoothGattCharacteristic notifyChar;
        BluetoothGattCharacteristic controlChar;
        long packets=0;
        long lastPacketMs=0;
        double emaDt=0;
        Integer rssi=null;

        boolean holdStable=false;
        Boolean holdCandidate=null;
        int holdCount=0;

        MeterConnection(Kind kind){ this.kind=kind; }

        void connect(BluetoothDevice d) {
            close();
            device=d;
            setStatus(kind,"СВЪРЗВАНЕ…",Color.rgb(255,208,94));
            log(kind+" connecting to "+safeName(d));
            try { gatt=d.connectGatt(MainActivity.this,false,gattCallback,BluetoothDevice.TRANSPORT_LE); }
            catch (SecurityException e) { toast("Bluetooth permission denied."); }
        }

        void close() {
            if (gatt!=null) {
                try { gatt.disconnect(); } catch (Exception ignored) {}
                try { gatt.close(); } catch (Exception ignored) {}
            }
            gatt=null; device=null; notifyChar=null; controlChar=null;
            packets=0;lastPacketMs=0;emaDt=0;rssi=null;
            holdStable=false;holdCandidate=null;holdCount=0;
            runOnUiThread(() -> {
                setStatus(kind,"НЕ Е СВЪРЗАН",Color.rgb(255,113,105));
                setButtons(kind,false);
                setRssi(kind,null);
                setLink(kind,0);
            });
        }

        void notePacket() {
            long now=System.currentTimeMillis();
            if(lastPacketMs>0){
                long dt=now-lastPacketMs;
                if(dt>20 && dt<5000) emaDt=emaDt==0?dt:emaDt*.78+dt*.22;
            }
            lastPacketMs=now; packets++;
        }

        int quality() {
            if(gatt==null || lastPacketMs==0) return 0;
            long age=System.currentTimeMillis()-lastPacketMs;
            double dt=emaDt==0?age:emaDt;
            if(age>2200)return 0;
            if(age<=500 && dt<=350)return 4;
            if(age<=800 && dt<=550)return 3;
            if(age<=1300 && dt<=900)return 2;
            return 1;
        }

        boolean updateHold(byte[] b) {
            boolean sample = MeterDecoders.rawOwonHold(b);
            if(holdCandidate==null || sample!=holdCandidate){holdCandidate=sample;holdCount=1;}
            else if(holdCount<2)holdCount++;
            if(holdCount>=2)holdStable=holdCandidate;
            return holdStable;
        }

        void sendHold() {
            if(kind!=Kind.OWON || gatt==null || controlChar==null){toast("OWON control not ready.");return;}
            byte[] p=new byte[]{0x03,0x01};
            try {
                int props=controlChar.getProperties();
                int writeType=(props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0
                        ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                        : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
                if(Build.VERSION.SDK_INT>=33){
                    int st=gatt.writeCharacteristic(controlChar,p,writeType);
                    log("OWON HOLD write status="+st);
                }else{
                    controlChar.setWriteType(writeType);
                    controlChar.setValue(p);
                    boolean ok=gatt.writeCharacteristic(controlChar);
                    log("OWON HOLD write="+ok);
                }
            } catch(SecurityException e){toast("Bluetooth permission denied.");}
        }

        void readRssi() {
            if(gatt==null)return;
            try { gatt.readRemoteRssi(); } catch(SecurityException ignored){}
        }

        final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
            @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){
                if(newState==BluetoothProfile.STATE_CONNECTED){
                    log(kind+" connected; discovering services...");
                    try { g.discoverServices(); } catch(SecurityException e){close();}
                }else if(newState==BluetoothProfile.STATE_DISCONNECTED){
                    log(kind+" disconnected (status "+status+")");
                    close();
                }
            }

            @Override public void onServicesDiscovered(BluetoothGatt g,int status){
                if(status!=BluetoothGatt.GATT_SUCCESS){log(kind+" service discovery failed "+status);close();return;}
                UUID su=kind==Kind.FLUKE?FLUKE_SERVICE:OWON_SERVICE;
                UUID nu=kind==Kind.FLUKE?FLUKE_MEAS:OWON_NOTIFY;
                BluetoothGattService s=g.getService(su);
                if(s==null){log(kind+" service missing");close();return;}
                notifyChar=s.getCharacteristic(nu);
                if(kind==Kind.OWON) controlChar=s.getCharacteristic(OWON_CONTROL);
                if(notifyChar==null){log(kind+" notify characteristic missing");close();return;}
                try{
                    if(!g.setCharacteristicNotification(notifyChar,true)){log(kind+" setCharacteristicNotification failed");close();return;}
                    BluetoothGattDescriptor d=notifyChar.getDescriptor(CCCD);
                    if(d==null){log(kind+" CCCD missing");close();return;}
                    if(Build.VERSION.SDK_INT>=33){
                        int st=g.writeDescriptor(d,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                        if(st!=0){log(kind+" descriptor write start failed "+st);}
                    }else{
                        d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                        if(!g.writeDescriptor(d))log(kind+" descriptor write start failed");
                    }
                }catch(SecurityException e){close();}
            }

            @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int status){
                if(CCCD.equals(d.getUuid()) && status==BluetoothGatt.GATT_SUCCESS){
                    runOnUiThread(() -> {
                        setStatus(kind,"СВЪРЗАН",Color.rgb(102,212,111));
                        setButtons(kind,true);
                    });
                    log(kind+" notifications enabled");
                }else if(CCCD.equals(d.getUuid())){
                    log(kind+" CCCD write failed "+status);
                }
            }

            @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){
                byte[] v=c.getValue();
                if(v!=null)handle(v.clone());
            }

            @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){
                handle(value==null?new byte[0]:value.clone());
            }

            @Override public void onReadRemoteRssi(BluetoothGatt g,int value,int status){
                if(status==BluetoothGatt.GATT_SUCCESS){
                    rssi=value;
                    runOnUiThread(() -> setRssi(kind,value));
                }
            }
        };

        void handle(byte[] data){
            notePacket();
            final MeterDecoders.Reading rd;
            if(kind==Kind.FLUKE) rd=MeterDecoders.decodeFluke(data);
            else rd=MeterDecoders.decodeOwon(data,updateHold(data));

            runOnUiThread(() -> {
                updateReading(kind,rd,packets);
                setLink(kind,quality());
            });
            if(rd.valid && logging) addCsv(kind,rd);
        }
    }

    private void updateReading(Kind k,MeterDecoders.Reading r,long packets){
        if(!r.valid)return;
        if(k==Kind.FLUKE){
            flukeValue.setText(r.value);flukeUnit.setText(r.unit);flukeMode.setText(r.mode);flukePackets.setText("Packets: "+packets);
        }else{
            owonValue.setText(r.value);owonUnit.setText(r.unit);owonMode.setText(r.mode+(r.hold?"   HOLD":""));owonPackets.setText("Packets: "+packets);
        }
    }

    private void setStatus(Kind k,String s,int color){
        TextView v=k==Kind.FLUKE?flukeStatus:owonStatus;
        v.setText(s);v.setTextColor(color);
    }

    private void setButtons(Kind k,boolean connected){
        if(k==Kind.FLUKE){
            flukeConnect.setEnabled(!connected);flukeDisconnect.setEnabled(connected);
        }else{
            owonConnect.setEnabled(!connected);owonDisconnect.setEnabled(connected);owonHold.setEnabled(connected);
        }
    }

    private void setRssi(Kind k,Integer value){
        TextView v=k==Kind.FLUKE?flukeRssi:owonRssi;
        v.setText(value==null?"RSSI  — dBm":"RSSI  "+value+" dBm");
    }

    private void setLink(Kind k,int q){
        String[] labels={"NO DATA","POOR ▮","WEAK ▮▮","OK ▮▮▮","GOOD ▮▮▮▮"};
        int color=q>=4?Color.rgb(102,212,111):q>=2?Color.rgb(255,208,94):Color.rgb(255,113,105);
        TextView v=k==Kind.FLUKE?flukeLink:owonLink;
        v.setText("LINK  "+labels[q]);v.setTextColor(color);
    }

    private final Runnable linkTicker=new Runnable(){
        @Override public void run(){
            setLink(Kind.FLUKE,fluke.quality());setLink(Kind.OWON,owon.quality());
            main.postDelayed(this,500);
        }
    };

    private final Runnable rssiTicker=new Runnable(){
        @Override public void run(){
            fluke.readRssi();owon.readRssi();
            main.postDelayed(this,2000);
        }
    };

    private void toggleLogging(){
        logging=!logging;
        logButton.setText(logging?"Стоп CSV лог":"Старт CSV лог");
        log("CSV logging "+(logging?"START":"STOP"));
    }

    private synchronized void addCsv(Kind k,MeterDecoders.Reading r){
        csvRows.add(new String[]{stamp.format(new Date()),k.toString(),r.value,r.unit,r.mode,r.hold?"1":"0",r.raw});
        runOnUiThread(() -> saveButton.setEnabled(true));
    }

    private void saveCsv(){
        if(csvRows.isEmpty()){toast("Няма записани данни.");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/csv");
        i.putExtra(Intent.EXTRA_TITLE,"ble_meter_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".csv");
        startActivityForResult(i,REQ_SAVE_CSV);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_SAVE_CSV && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            writeCsv(data.getData());
        }
    }

    private synchronized void writeCsv(Uri uri){
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            if(out==null)throw new Exception("openOutputStream returned null");
            out.write(0xEF);out.write(0xBB);out.write(0xBF);
            StringBuilder sb=new StringBuilder("sep=,\r\n\"timestamp\",\"source\",\"value\",\"unit\",\"mode\",\"hold\",\"raw\"\r\n");
            for(String[] row:csvRows){
                for(int i=0;i<row.length;i++){
                    if(i>0)sb.append(',');
                    sb.append('"').append(row[i].replace("\"","\"\"")).append('"');
                }
                sb.append("\r\n");
            }
            out.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            toast("CSV записан.");
        }catch(Exception e){toast("CSV error: "+e.getMessage());}
    }

    private void toggleKeepScreen(){
        keepScreen=!keepScreen;
        if(keepScreen)getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        screenButton.setText(keepScreen?"Разреши заспиване":"Дръж екрана включен");
    }

    private void log(String s){
        runOnUiThread(() -> {
            String old=eventLog.getText().toString();
            String line=new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date())+"  "+s+"\n";
            String n=old+line;
            if(n.length()>7000)n=n.substring(n.length()-7000);
            eventLog.setText(n);
        });
    }

    private void toast(String s){ runOnUiThread(() -> Toast.makeText(this,s,Toast.LENGTH_LONG).show()); }
}
