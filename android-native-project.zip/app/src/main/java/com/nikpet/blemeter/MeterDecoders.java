package com.nikpet.blemeter;

import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class MeterDecoders {
    private MeterDecoders() {}

    public static final class Reading {
        public final boolean valid;
        public final String value;
        public final String unit;
        public final String mode;
        public final boolean hold;
        public final String raw;

        public Reading(boolean valid, String value, String unit, String mode, boolean hold, String raw) {
            this.valid = valid;
            this.value = value;
            this.unit = unit;
            this.mode = mode;
            this.hold = hold;
            this.raw = raw;
        }
    }

    public static Reading decodeFluke(byte[] data) {
        if (data == null || data.length < 5 || data.length >= 96) return invalid("FLUKE length");
        String s = new String(data, StandardCharsets.UTF_8).trim();
        String[] p = s.split(",", -1);
        if (p.length < 3 || !(p[0].equals("M") || p[0].equals("T"))) return invalid(s);

        final double n;
        try { n = Double.parseDouble(p[1].trim()); }
        catch (Exception e) { return invalid(s); }

        String baseUnit = p[2].trim();
        String acdc = p.length >= 4 ? p[3].trim().toUpperCase(Locale.US) : "";
        String[] eng = engineering(n, baseUnit);
        return new Reading(true, eng[0], eng[1], flukeMode(baseUnit, acdc, p[0].equals("T")), false, s);
    }

    private static String[] engineering(double value, String baseUnit) {
        double scaled = value;
        String prefix = "";
        boolean scalable = baseUnit.equals("V") || baseUnit.equals("A") || baseUnit.equals("Ohm")
                || baseUnit.equals("Hz") || baseUnit.equals("F") || baseUnit.equals("s");
        double a = Math.abs(value);
        if (scalable && value != 0.0) {
            if (a >= 1e9) { scaled=value/1e9; prefix="G"; }
            else if (a >= 1e6) { scaled=value/1e6; prefix="M"; }
            else if (a >= 1e3) { scaled=value/1e3; prefix="k"; }
            else if (a >= 1.0) { scaled=value; }
            else if (a >= 1e-3) { scaled=value*1e3; prefix="m"; }
            else if (a >= 1e-6) { scaled=value*1e6; prefix="u"; }
            else if (a >= 1e-9) { scaled=value*1e9; prefix="n"; }
            else { scaled=value*1e12; prefix="p"; }
        }

        double as = Math.abs(scaled);
        int dec = as >= 100 ? 3 : as >= 10 ? 4 : as >= 1 ? 5 : 6;
        String text = String.format(Locale.US, "%." + dec + "f", scaled);
        while (text.contains(".") && text.endsWith("0")) text = text.substring(0, text.length()-1);
        if (text.endsWith(".")) text = text.substring(0, text.length()-1);
        if (text.equals("-0")) text = "0";
        text = text.replace('.', ',');
        return new String[]{text, prefix + baseUnit};
    }

    private static String flukeMode(String unit, String acdc, boolean test) {
        String t;
        if (unit.equals("V")) t=(acdc.isEmpty()?"":acdc+" ")+"VOLT";
        else if (unit.equals("A")) t=(acdc.isEmpty()?"":acdc+" ")+"CURRENT";
        else if (unit.equals("Ohm")) t="OHM";
        else if (unit.equals("Hz")) t="FREQUENCY";
        else if (unit.equals("F")) t="CAPACITANCE";
        else if (unit.equals("s")) t="TIME";
        else t=(acdc.isEmpty()?"":acdc+" ")+unit;
        return (test?"TEST ":"")+t;
    }

    public static Reading decodeOwon(byte[] b, boolean hold) {
        if (b == null || b.length < 13) return invalid("OWON length");
        int meta = ((b[1] & 0xFF) << 8) | (b[0] & 0xFF);
        int raw = ((b[4] & 0xFF) << 8) | (b[3] & 0xFF);
        int fn = (meta >> 6) & 0x0F;
        int scale = (meta >> 3) & 0x03;
        int decimal = meta & 0x07;
        boolean negative = (b[5] & 0x80) != 0 && raw != 0;

        String value;
        if (isOverload(fn, raw)) {
            value = "OL";
        } else {
            String digits = Integer.toString(raw);
            if (decimal == 0) value = digits;
            else if (digits.length() > decimal) {
                int pos = digits.length() - decimal;
                value = digits.substring(0,pos) + "," + digits.substring(pos);
            } else {
                StringBuilder sb = new StringBuilder("0,");
                for (int i=0; i<decimal-digits.length(); i++) sb.append('0');
                sb.append(digits);
                value = sb.toString();
            }
            if (negative) value = "-" + value;
        }

        String[] um = unitMode(meta, fn, scale);
        return new Reading(true, value, um[0], um[1], hold, hex(b));
    }

    public static boolean rawOwonHold(byte[] b) {
        return b != null && b.length > 12 && (b[12] & 0x01) != 0;
    }

    private static boolean isOverload(int fn, int raw) {
        if (fn == 11) return raw > 8000;
        if (fn == 6) return raw >= 20000;
        return raw >= 21000;
    }

    private static String[] unitMode(int meta, int fn, int scale) {
        boolean mv = (fn==0 || fn==1) && ((meta & 0x20)==0);
        switch(fn) {
            case 0: return new String[]{mv?"mV":"V","DC VOLT"};
            case 1: return new String[]{mv?"mV":"V","AC VOLT"};
            case 2: return new String[]{"A","DC CURRENT"};
            case 3: return new String[]{"A","AC CURRENT"};
            case 4: return new String[]{new String[]{"Ohm","kOhm","MOhm","GOhm"}[scale&3],"OHM"};
            case 5: return new String[]{new String[]{"pF","nF","uF","mF"}[scale&3],"CAPACITANCE"};
            case 6: return new String[]{new String[]{"Hz","kHz","MHz","GHz"}[scale&3],"FREQUENCY"};
            case 10:return new String[]{"V","DIODE"};
            case 11:return new String[]{"Ohm","CONTINUITY"};
            case 13:return new String[]{"","NCV"};
            case 14:return new String[]{"V","SCOPE V"};
            case 15:return new String[]{"A","SCOPE A"};
            default:return new String[]{"","UNKNOWN"};
        }
    }

    public static String hex(byte[] b) {
        if (b == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<b.length; i++) {
            if (i>0) sb.append(' ');
            sb.append(String.format(Locale.US, "%02X", b[i] & 0xFF));
        }
        return sb.toString();
    }

    private static Reading invalid(String raw) {
        return new Reading(false,"--","","NO DATA",false,raw==null?"":raw);
    }
}
